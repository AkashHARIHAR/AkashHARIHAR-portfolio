/* Select Navigation Elements */
const navMenu = document.getElementById('sidebar'),
      navToggle = document.getElementById('nav-toggle'),
      navClose = document.getElementById('nav-close');

/* Show Sidebar Panel */
if(navToggle){
    navToggle.addEventListener('click', () => {
        navMenu.classList.add('show-sidebar');
    });
}

/* Hide Sidebar Panel */
if(navClose){
    navClose.addEventListener('click', () => {
        navMenu.classList.remove('show-sidebar');
    });
}

/* Clear Sidebar Overlay on NavLink Selection */
const navLink = document.querySelectorAll('.nav__link');

function linkAction(){
    const navMenu = document.getElementById('sidebar');
    navMenu.classList.remove('show-sidebar');
}
navLink.forEach(n => n.addEventListener('click', linkAction));