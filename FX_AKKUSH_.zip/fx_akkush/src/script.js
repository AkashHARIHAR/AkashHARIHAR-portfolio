window.addEventListener("load", function () {

    setTimeout(function () {

        document.querySelector(".loader").classList.add("hidden");

    }, 1800);

});